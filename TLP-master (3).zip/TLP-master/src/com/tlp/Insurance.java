package com.tlp;

public interface Insurance {
	
	public void setRating();
	
	public String getRating();
	
	public Person getPersonDetails();
	
	
}
